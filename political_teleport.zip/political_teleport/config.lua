-- config.lua

Config = {}

-- ===== UI THEME (only change here) =====
-- options: "dark", "usa", "halloween", "christmas"
Config.UITheme = "usa"

-- Decorative overlays per theme
Config.EnableDecor   = true                 -- set false to hide themed art
Config.DecorDensity  = "full"               -- "none" | "light" | "full"

-- ===== Popup behavior =====
Config.ReminderDelaySeconds   = 60          -- “Remind me later” delay (sec)
Config.PopupAutoCloseSeconds  = 0           -- 0 = don't auto-close

-- ===== Calendar toggle (F7 panel) =====
Config.Calendar = {
    Command = "policalendar",
    OpenKey = "F7"
}

-- ===== Weekly sample schedule =====
Config.WeeklySchedule = {
    Sunday = {
        { name = "Town Hall Prep", start = "08:30", finish = "09:00", desc = "Staff sync & briefing" },
        { name = "Constituent Calls", start = "14:00", finish = "15:00" },
        { name = "Community BBQ", start = "17:30", finish = "18:00" },
    },
    Monday = {
        { name = "Press Conference", start = "08:30", finish = "09:00" },
        { name = "Committee Hearing", start = "10:00", finish = "11:00" },
        { name = "Policy Workshop", start = "13:00", finish = "14:00" },
        { name = "Rally", start = "17:30", finish = "18:00" },
    },
    Tuesday = {
        { name = "Budget Review", start = "09:00", finish = "10:00" },
        { name = "Lobby Briefing", start = "12:00", finish = "12:30" },
        { name = "Debate Practice", start = "15:00", finish = "16:00" },
    },
    Wednesday = {
        { name = "School Visit", start = "08:00", finish = "08:30" },
        { name = "Press Conference", start = "13:30", finish = "14:00" },
    },
    Thursday = {
        { name = "Committee Hearing", start = "10:00", finish = "11:30" },
        { name = "Rally", start = "18:00", finish = "18:30" },
    },
    Friday = {
        { name = "Office Hours", start = "09:00", finish = "10:00" },
        { name = "Town Hall", start = "16:30", finish = "17:30" },
    },
    Saturday = {
        { name = "Parade", start = "11:00", finish = "11:45" },
        { name = "Volunteer Meetup", start = "14:00", finish = "15:00" },
    },
}

-- ===== Random teleport locations (placeholders) =====
Config.TeleportLocations = {
    { x = -75.0,   y = -818.0, z = 326.0, w = 90.0  },  -- Maze Bank
    { x = -545.0,  y = -204.0, z = 38.2,  w = 0.0   },  -- City Hall
    { x = 233.0,   y = -410.0, z = 48.1,  w = 180.0 },  -- Courthouse
    { x = -1295.0, y = -566.0, z = 31.7,  w = 270.0 },  -- Del Perro
    { x = 1854.0,  y = 3683.0, z = 34.3,  w = 200.0 },  -- Sandy
    { x = -428.0,  y = 1123.0, z = 325.8, w = 45.0  },  -- Vinewood
}
