-- client.lua (in-game clock + day rollover + F7-only calendar + theme/decor push)

-- ===== State =====
local eventsToday = {}
local nextEventIdx = nil
local ignoredEvents = {}     -- event.id -> true once popup shown
local reminderAt = nil       -- GetGameTimer() ms for reminder
local calendarOpen = false
local lastNowSec = nil       -- detect time jumps
local curWday = (GetClockDayOfWeek() or 0) + 1  -- 1..7 (Sun..Sat)

-- ===== Helpers =====
local function getSecondsSinceMidnight()
    local h = GetClockHours()
    local m = GetClockMinutes()
    local s = GetClockSeconds()
    return h * 3600 + m * 60 + s
end

local function parseHHMM(str)
    local h, m = string.match(str or "", "^(%d?%d):(%d%d)$")
    h = tonumber(h or 0) or 0
    m = tonumber(m or 0) or 0
    h = math.max(0, math.min(23, h))
    m = math.max(0, math.min(59, m))
    return h * 3600 + m * 60
end

local function weekdayNameByIndex(idx)
    local map = {"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"}
    return map[((idx - 1) % 7) + 1]
end

local function buildTodayEvents()
    local wdName = weekdayNameByIndex(curWday)
    local list = {}
    local day = (Config.WeeklySchedule and Config.WeeklySchedule[wdName]) or {}
    for i, ev in ipairs(day) do
        list[#list+1] = {
            id = i,
            name = ev.name or "Event",
            startSec = parseHHMM(ev.start),
            endSec = parseHHMM(ev.finish),
            desc = ev.desc or ""
        }
    end
    table.sort(list, function(a,b) return a.startSec < b.startSec end)
    return list
end

local function findNextEvent(nowSec)
    for i, ev in ipairs(eventsToday) do
        if nowSec <= ev.startSec then return i end
    end
    return nil
end

local function getCurrentEvent(nowSec)
    for i, ev in ipairs(eventsToday) do
        if nowSec >= ev.startSec and nowSec <= ev.endSec then
            return i, ev
        end
    end
    return nil, nil
end

-- ===== Teleport =====
local function safeTeleportRandom()
    if not (Config.TeleportLocations and #Config.TeleportLocations > 0) then return end
    local ped = PlayerPedId()
    local choice = Config.TeleportLocations[math.random(1, #Config.TeleportLocations)]
    local x, y, z, h = choice.x, choice.y, choice.z, (choice.w or 0.0)

    DoScreenFadeOut(500)
    while not IsScreenFadedOut() do Wait(0) end

    if IsPedInAnyVehicle(ped, false) then
        local veh = GetVehiclePedIsIn(ped, false)
        SetEntityCoords(veh, x, y, z, false, false, false, false)
        SetEntityHeading(veh, h)
    else
        SetEntityCoords(ped, x, y, z, false, false, false, false)
        SetEntityHeading(ped, h)
    end

    Wait(300)
    DoScreenFadeIn(500)
end

-- ===== THEME / DECOR push (config-only) =====
local function pushUITheme()
    SendNUIMessage({
        type = 'theme:set',
        theme = Config.UITheme or 'dark',
        decorEnabled = Config.EnableDecor ~= false,
        decorDensity = Config.DecorDensity or 'full'
    })
end

CreateThread(function()
    -- tiny delay so NUI is ready
    Wait(300)
    pushUITheme()
end)

-- ===== NUI bridge =====
RegisterNUICallback('ui:teleport', function(_, cb)
    SetNuiFocus(false, false)
    safeTeleportRandom()
    cb({ ok = true })
end)

RegisterNUICallback('ui:remind', function(_, cb)
    SetNuiFocus(false, false)
    reminderAt = GetGameTimer() + (Config.ReminderDelaySeconds or 60) * 1000
    SendNUIMessage({ type = 'notify', message = 'You will be reminded in 1 minute.' })
    cb({ ok = true })
end)

RegisterNUICallback('ui:ignore', function(_, cb)
    SetNuiFocus(false, false)
    if nextEventIdx ~= nil then
        local ev = eventsToday[nextEventIdx]
        if ev then ignoredEvents[ev.id] = true end
    end
    cb({ ok = true })
end)

RegisterNUICallback('ui:close', function(_, cb)
    SetNuiFocus(false, false)
    calendarOpen = false
    SendNUIMessage({ type = 'calendar:toggle', open = false })
    cb({ ok = true })
end)

RegisterCommand(Config.Calendar.Command, function()
    calendarOpen = not calendarOpen
    SetNuiFocus(calendarOpen, calendarOpen)
    SendNUIMessage({ type = 'calendar:toggle', open = calendarOpen })
end)

RegisterKeyMapping(Config.Calendar.Command, 'Open Political Calendar', 'keyboard', Config.Calendar.OpenKey)

-- ===== Main loop =====
CreateThread(function()
    math.randomseed(GetGameTimer() + math.random(99999))
    eventsToday = buildTodayEvents()
    nextEventIdx = findNextEvent(getSecondsSinceMidnight())

    while true do
        local nowSec = getSecondsSinceMidnight()

        -- Detect midnight wrap (or strong backward jump) and advance weekday
        if lastNowSec ~= nil and nowSec < lastNowSec - 30 then
            curWday = (curWday % 7) + 1
            eventsToday = buildTodayEvents()
            ignoredEvents = {}
            nextEventIdx = findNextEvent(nowSec)
        end
        lastNowSec = nowSec

        -- Track current + next
        local curIdx, curEv = getCurrentEvent(nowSec)
        if curIdx then
            nextEventIdx = curIdx
        else
            if nextEventIdx == nil or (eventsToday[nextEventIdx] and nowSec > eventsToday[nextEventIdx].startSec) then
                nextEventIdx = findNextEvent(nowSec)
            end
        end

        -- Choose "next" distinct from current for the top box
        local nextDisplay = nil
        if curIdx then nextDisplay = eventsToday[curIdx + 1] else nextDisplay = (nextEventIdx and eventsToday[nextEventIdx]) or nil end

        -- UI tick (top info + F7 panel data + weekday)
        SendNUIMessage({
            type = 'tick:update',
            now = nowSec,
            weekdayIndex = curWday,     -- 1..7
            currentEvent = curEv,
            nextEvent = nextDisplay,
            events = eventsToday,       -- used by the panel (bottom center)
        })

        -- Popup: fire once when time >= start OR when reminder triggers
        if nextEventIdx ~= nil then
            local ev = eventsToday[nextEventIdx]
            if ev then
                local reached = (nowSec >= ev.startSec)
                local reminderDue = (reminderAt ~= nil and GetGameTimer() >= reminderAt)
                if (reached or reminderDue) and not ignoredEvents[ev.id] then
                    SetNuiFocus(true, true)
                    SendNUIMessage({ type = 'popup:show', event = ev, autoClose = Config.PopupAutoCloseSeconds or 15 })
                    ignoredEvents[ev.id] = true
                    if reminderDue then reminderAt = nil end
                end
            end
        end

        Wait(150) -- responsive detection; UI marker is animated in JS
    end
end)

-- ===== Test Command =====
RegisterCommand('eventpopup', function()
    local ev = { name = "Test Event", startSec = 8*3600+30*60, endSec = 8*3600+45*60, desc = "NUI test popup" }
    SetNuiFocus(true, true)
    SendNUIMessage({ type = 'popup:show', event = ev, autoClose = 0 })
end)
