-- fxmanifest.lua


fx_version 'cerulean'
game 'gta5'
lua54 'yes'


ui_page 'html/ui.html'


files {
'html/ui.html',
'html/ui.css',
'html/ui.js'
}


shared_scripts {
'config.lua'
}


client_scripts {
'client.lua'
}


server_scripts {
'server.lua'
}