// html/ui.js (full updated)

const currentName = document.getElementById('currentName');
const currentTime = document.getElementById('currentTime');
const nextName    = document.getElementById('nextName');
const nextTime    = document.getElementById('nextTime');

const calendar    = document.getElementById('calendar');
const dayLabel    = document.getElementById('dayLabel');
const timeRuler   = document.getElementById('timeRuler');
const eventLayer  = document.getElementById('eventLayer');
const timeMarker  = document.getElementById('timeMarker');

const eventList   = document.getElementById('eventList');
const btnClose    = document.getElementById('btnClose');

const popup       = document.getElementById('popup');
const popupTitle  = document.getElementById('popupTitle');
const popupTime   = document.getElementById('popupTime');
const btnTeleport = document.getElementById('btnTeleport');
const btnRemind   = document.getElementById('btnRemind');
const btnIgnore   = document.getElementById('btnIgnore');

const notifyBox   = document.getElementById('notify');
const decorRoot   = document.getElementById('decor');
const infoBoxes   = document.getElementById('infoBoxes');

/* ===== Theme support (from config via client.lua) ===== */
const THEMES = ['dark','usa','halloween','christmas'];
let decorEnabled = true;
let decorDensity = 'full';
let currentTheme = 'dark';

function setTheme(name){
  THEMES.forEach(t => document.body.classList.remove('theme-'+t));
  if (THEMES.includes(name)) { document.body.classList.add('theme-'+name); currentTheme = name; }
  else { document.body.classList.add('theme-dark'); currentTheme = 'dark'; }
  sizeDecorBand();    // band runs from top to BOTTOM of boxes
  renderDecor(currentTheme);
}

/* ===== Small inline SVGs ===== */
const svg = {
  star: `
<svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
  <polygon points="10,1 12.8,7.2 19.5,7.3 14,11.5 16,18 10,14.2 4,18 6,11.5 0.5,7.3 7.2,7.2"
           fill="#ffffffcc"/>
</svg>`.trim(),
  pumpkin: `
<svg viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg">
  <ellipse cx="30" cy="34" rx="22" ry="16" fill="#ff8b2f"/>
  <ellipse cx="22" cy="34" rx="10" ry="14" fill="#ff9d4f"/>
  <ellipse cx="38" cy="34" rx="10" ry="14" fill="#ff9d4f"/>
  <rect x="27" y="14" width="6" height="8" rx="2" fill="#4c8b2b"/>
</svg>`.trim(),
  bat: `
<svg viewBox="0 0 80 40" xmlns="http://www.w3.org/2000/svg">
  <path d="M5,25 C15,5 25,5 35,20 C40,15 45,15 50,20 C55,5 65,5 75,25 C65,20 55,22 50,28 C45,24 35,24 30,28 C25,22 15,20 5,25"
        fill="#2b1d3a"/>
</svg>`.trim(),
  ghost: `
<svg viewBox="0 0 36 48" xmlns="http://www.w3.org/2000/svg">
  <path d="M18 4c8 0 14 6 14 14v22l-4-3-4 3-4-3-4 3-4-3-4 3V18C8 10 10 4 18 4z" fill="#ffffffdd"/>
  <circle cx="13" cy="18" r="2.2" fill="#1a2333"/>
  <circle cx="23" cy="18" r="2.2" fill="#1a2333"/>
</svg>`.trim(),
  tree: `
<svg viewBox="0 0 60 80" xmlns="http://www.w3.org/2000/svg">
  <polygon points="30,5 55,35 5,35" fill="#2ecc71"/>
  <polygon points="30,20 50,50 10,50" fill="#27ae60"/>
  <polygon points="30,35 45,65 15,65" fill="#1f9e57"/>
  <rect x="26" y="65" width="8" height="10" fill="#8e5a3b"/>
</svg>`.trim(),
  snow: `
<svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
  <path d="M10 0 L10 20 M0 10 L20 10 M3 3 L17 17 M17 3 L3 17" stroke="#ffffffcc" stroke-width="2" fill="none"/>
</svg>`.trim()
};

function makeItem(svgStr, style){
  const d = document.createElement('div');
  d.className = 'decor-item';
  d.style = style || '';
  d.innerHTML = svgStr;
  return d;
}
function rnd(min, max){ return Math.random()*(max-min)+min; }

/* --- Decor band sizing: extend from top to the BOTTOM of the boxes (no further) --- */
function sizeDecorBand(){
  const rect = infoBoxes.getBoundingClientRect();
  const band = Math.max(0, Math.round(rect.bottom)); // height from top to bottom of boxes
  decorRoot.style.height = `${band}px`;
  // Let items travel beyond the band; band clips at its bottom edge
  decorRoot.style.setProperty('--dropDist', `${band + 40}px`);
}

/* ===== USA stars that relocate (not same stars blinking) ===== */
let usaStarTimeouts = [];
function clearUsaStars(){
  usaStarTimeouts.forEach(id => clearTimeout(id));
  usaStarTimeouts = [];
}
function spawnUsaStar(bandH){
  const x = rnd(2,98), y = rnd(2, Math.max(2, bandH - 14));
  const s = rnd(10,20), t = rnd(1.8,3.2), delay = rnd(0,1.5);

  const el = makeItem(svg.star, `
    left:${x}vw; top:${y}px; width:${s}px; opacity:0;
    transition:opacity 1.2s ease;
    animation: shimmer ${t}s ease-in-out ${delay}s infinite;
  `);
  decorRoot.appendChild(el);

  // fade in
  const id1 = setTimeout(()=>{ el.style.opacity = 0.9; }, 20);

  // lifetime then fade out & respawn elsewhere
  const life = rnd(6000, 10000);
  const id2 = setTimeout(()=>{ el.style.opacity = 0; }, life - 1200);
  const id3 = setTimeout(()=>{
    if (el.parentNode) el.parentNode.removeChild(el);
    const id4 = setTimeout(()=> spawnUsaStar(bandH), rnd(200, 800));
    usaStarTimeouts.push(id4);
  }, life);

  usaStarTimeouts.push(id1, id2, id3);
}

/* ===== Decor (USA: shimmering stars; Halloween: pumpkins+bats+ghosts; Christmas: snow+trees) ===== */
function renderDecor(theme){
  decorRoot.innerHTML = '';
  clearUsaStars();
  if (!decorEnabled) return;

  const density = (decorDensity||'full').toLowerCase();
  const bandH = decorRoot.getBoundingClientRect().height || 60;

  if (theme === 'usa'){
    const count = density === 'light' ? 18 : 34;
    for (let i=0;i<count;i++) spawnUsaStar(bandH);
    return;
  }

  if (theme === 'halloween'){
    const pumpkins = density === 'light' ? 10 : 18;
    const bats     = density === 'light' ? 6  : 10;
    const ghosts   = density === 'light' ? 6  : 10;

    for (let i=0;i<pumpkins;i++){
      const x = rnd(2,98), s = rnd(18,28), d = rnd(0,3), t = rnd(4,7);
      const el = makeItem(svg.pumpkin, `
        left:${x}vw; top:-28px; width:${s}px; opacity:${rnd(.75,.95)};
        animation: fallTop ${t}s linear ${d}s infinite;`);
      decorRoot.appendChild(el);
    }
    for (let i=0;i<bats;i++){
      const x = rnd(2,98), s = rnd(26,38), d = rnd(0,3), t = rnd(4.5,7.5);
      const el = makeItem(svg.bat, `
        left:${x}vw; top:-30px; width:${s}px; opacity:${rnd(.7,.9)};
        animation: fallTop ${t}s linear ${d}s infinite;`);
      decorRoot.appendChild(el);
    }
    for (let i=0;i<ghosts;i++){
      const x = rnd(2,98), s = rnd(16,24), d = rnd(0,3), t = rnd(4.5,7);
      const el = makeItem(svg.ghost, `
        left:${x}vw; top:-34px; width:${s}px; opacity:${rnd(.7,.92)};
        animation: fallTop ${t}s linear ${d}s infinite;`);
      decorRoot.appendChild(el);
    }
    return;
  }

  if (theme === 'christmas'){
    const flakes = density === 'light' ? 20 : 36;
    const trees  = density === 'light' ? 6  : 12;

    for (let i=0;i<flakes;i++){
      const x = rnd(1,99), s = rnd(10,16), d = rnd(0,3), t = rnd(4,7);
      const el = makeItem(svg.snow, `
        left:${x}vw; top:-24px; width:${s}px; opacity:${rnd(.45,.9)};
        animation: fallTop ${t}s linear ${d}s infinite;`);
      decorRoot.appendChild(el);
    }
    for (let i=0;i<trees;i++){
      const x = rnd(2,98), s = rnd(14,22), d = rnd(0,3), t = rnd(4.5,7.5);
      const el = makeItem(svg.tree, `
        left:${x}vw; top:-28px; width:${s}px; opacity:${rnd(.7,.95)};
        animation: fallTop ${t}s linear ${d}s infinite;`);
      decorRoot.appendChild(el);
    }
    return;
  }
}

/* ===== Utils ===== */
function fmt(sec){ const h=Math.floor(sec/3600), m=Math.floor((sec%3600)/60); return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}`; }
function weekdayName(idx){ return ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"][((idx-1)%7+7)%7] || "Monday"; }
function showToast(msg, ms=3000){ notifyBox.textContent = msg||""; notifyBox.classList.remove('hidden'); setTimeout(()=>notifyBox.classList.add('hidden'), ms); }

/* ===== Ruler once ===== */
function renderRuler(){
  timeRuler.innerHTML = '';
  for (let h=0; h<=24; h++){
    const x = (h/24)*100;
    const tick = document.createElement('div');
    tick.className = 'tick';
    tick.style.left = `${x}%`;
    timeRuler.appendChild(tick);

    if (h <= 23){
      const label = document.createElement('div');
      label.className = 'tick-label';
      label.style.left = `${x}%`;
      label.textContent = String(h).padStart(2,'0') + ':00';
      timeRuler.appendChild(label);
    }
  }
}

/* ===== Event pills ===== */
function renderEvents(events){
  eventLayer.innerHTML = '';
  (events||[]).forEach(ev=>{
    const startPct = (ev.startSec / 86400) * 100;
    const endPct   = (ev.endSec   / 86400) * 100;
    const widthPct = Math.max(0.5, endPct - startPct);
    const block = document.createElement('div');
    block.className = 'event-block';
    block.style.left = `${startPct}%`;
    block.style.width = `${widthPct}%`;
    block.title = `${ev.name}  ${fmt(ev.startSec)}-${fmt(ev.endSec)}`;
    block.textContent = ev.name;
    eventLayer.appendChild(block);
  });
}

/* ===== Top boxes ===== */
function setBoxes(cur, next){
  if (cur){
    currentName.textContent = cur.name;
    currentTime.textContent = `${fmt(cur.startSec)}-${fmt(cur.endSec)}`;
  }else{
    currentName.textContent = '—';
    currentTime.textContent = '—';
  }
  if (next){
    nextName.textContent = next.name || '—';
    nextTime.textContent = next.startSec ? `${fmt(next.startSec)}-${fmt(next.endSec)}` : '—';
  }else{
    nextName.textContent = '—';
    nextTime.textContent = '—';
  }
}

/* ===== List ===== */
function renderList(events, nowSec){
  eventList.innerHTML = '';
  (events||[]).forEach(ev=>{
    const row = document.createElement('div');
    row.className = 'event';
    if (nowSec >= ev.startSec && nowSec <= ev.endSec) row.classList.add('now');

    const t = document.createElement('div');
    t.className = 'event-time';
    t.textContent = `${fmt(ev.startSec)} - ${fmt(ev.endSec)}`;

    const right = document.createElement('div');
    const name = document.createElement('div');
    name.className = 'event-name';
    name.textContent = ev.name;

    const desc = document.createElement('div');
    desc.className = 'event-desc';
    desc.textContent = ev.desc || '';

    right.appendChild(name);
    right.appendChild(desc);
    row.appendChild(t);
    row.appendChild(right);
    eventList.appendChild(row);
  });
}

/* ===== Smooth marker (no snapping) ===== */
let baseNowSec = 0;  // authoritative seconds since midnight at last tick
let basePerf   = 0;  // performance.now() at last tick
let animOn     = false;

function predictedSec(){
  const dt = (performance.now() - basePerf) / 1000;
  return (baseNowSec + dt) % 86400;
}
function setMarker(sec){
  const x = (sec / 86400) * 100;
  timeMarker.style.left = `${x}%`;
}
function startAnim(){
  if (animOn) return;
  animOn = true;
  const loop = () => { setMarker(predictedSec()); requestAnimationFrame(loop); };
  requestAnimationFrame(loop);
}
function resyncAuthoritative(nowSec){
  baseNowSec = nowSec;
  basePerf   = performance.now();
  startAnim();
}

/* ===== NUI messages ===== */
window.addEventListener('message', (e)=>{
  const d = e.data || {};

  if (d.type === 'theme:set'){
    decorEnabled = !!d.decorEnabled;
    decorDensity = d.decorDensity || 'full';
    setTheme(d.theme || 'dark');
    return;
  }

  if (d.type === 'tick:update'){
    dayLabel.textContent = weekdayName(d.weekdayIndex || 1);
    setBoxes(d.currentEvent, d.nextEvent);
    renderList(d.events, d.now);
    renderEvents(d.events);
    if (!timeRuler.hasChildNodes()) renderRuler();

    resyncAuthoritative(d.now);  // smooth marker
    return;
  }

  if (d.type === 'calendar:toggle'){
    calendar.classList.toggle('hidden', !d.open);
    return;
  }

  if (d.type === 'popup:show'){
    const ev = d.event; if (!ev) return;
    popupTitle.textContent = ev.name;
    popupTime.textContent = `${fmt(ev.startSec)}-${fmt(ev.endSec)}`;
    popup.classList.remove('hidden');

    const seconds = d.autoClose || 0;
    if (seconds > 0){
      setTimeout(()=>{
        popup.classList.add('hidden');
        fetch(`https://${GetParentResourceName()}/ui:close`, {
          method:'POST',
          headers:{'Content-Type':'application/json; charset=UTF-8'},
          body: JSON.stringify({})
        });
      }, seconds * 1000);
    }
    return;
  }

  if (d.type === 'notify'){
    showToast(d.message || '');
    return;
  }
});

/* ===== Buttons → callbacks to client ===== */
function nui(name, payload={}){
  fetch(`https://${GetParentResourceName()}/${name}`, {
    method:'POST',
    headers:{'Content-Type':'application/json; charset=UTF-8'},
    body: JSON.stringify(payload)
  });
}
btnTeleport.addEventListener('click', ()=>{ popup.classList.add('hidden'); nui('ui:teleport'); });
btnRemind  .addEventListener('click', ()=>{ popup.classList.add('hidden'); nui('ui:remind');  });
btnIgnore  .addEventListener('click', ()=>{ popup.classList.add('hidden'); nui('ui:ignore');  });
btnClose   .addEventListener('click', ()=>{ nui('ui:close'); });

// Prevent right-click
window.addEventListener('contextmenu', e=>e.preventDefault());

// Keep decor band sized on load/resize (so it stops at bottom of boxes)
window.addEventListener('load',  ()=>{ sizeDecorBand(); renderDecor(currentTheme); });
window.addEventListener('resize',()=>{ sizeDecorBand(); renderDecor(currentTheme); });

// Start animation; marker syncs each tick
startAnim();
