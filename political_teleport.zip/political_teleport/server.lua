-- server.lua (provides epoch, seconds-since-midnight, weekday)

local function now()
    return os.time()
end

RegisterNetEvent('political_teleport:requestTime')
AddEventHandler('political_teleport:requestTime', function()
    local src = source
    local epoch = now()
    local t = os.date("*t", epoch)
    local ss = t.hour * 3600 + t.min * 60 + t.sec
    -- os.date("*t").wday: Sunday=1 .. Saturday=7
    TriggerClientEvent('political_teleport:timeSync', src, {
        epoch = epoch,
        ssMidnight = ss,
        wday = t.wday
    })
end)
